import pygame

from config import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    TILE_SIZE,
    FPS,
)

from game import Game


# =============================================================
# ИНИЦИАЛИЗАЦИЯ
# =============================================================

pygame.init()

screen = pygame.display.set_mode(
    (
        SCREEN_WIDTH,
        SCREEN_HEIGHT
    )
)

pygame.display.set_caption(
    "Последний сектор"
)

clock = pygame.time.Clock()


# =============================================================
# ШРИФТЫ
# =============================================================

FONT = pygame.font.Font(
    None,
    24
)

SMALL_FONT = pygame.font.Font(
    None,
    18
)

BIG_FONT = pygame.font.Font(
    None,
    34
)


# =============================================================
# ИГРА
# =============================================================

game = Game()


# =============================================================
# ЦВЕТА
# =============================================================

BG = (
    5,
    9,
    20
)

PANEL = (
    11,
    17,
    32
)

PANEL_LIGHT = (
    20,
    29,
    48
)

GRID = (
    35,
    50,
    75
)

TEXT = (
    225,
    235,
    250
)

MUTED = (
    130,
    145,
    170
)

CYAN = (
    70,
    210,
    255
)

RED = (
    245,
    80,
    90
)

GREEN = (
    90,
    220,
    150
)

GOLD = (
    240,
    190,
    70
)

PURPLE = (
    165,
    100,
    230
)

WHITE = (
    245,
    250,
    255
)


# =============================================================
# РАЗМЕРЫ КАРТЫ
# =============================================================

BOARD_X = 30
BOARD_Y = 80

BOARD_SIZE = 7

BOARD_WIDTH = (
    BOARD_SIZE * TILE_SIZE
)

BOARD_HEIGHT = (
    BOARD_SIZE * TILE_SIZE
)


# =============================================================
# СОСТОЯНИЕ UI
# =============================================================

selected_tile = None

action_menu = None


# =============================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# =============================================================

def draw_text(
    text,
    x,
    y,
    font=FONT,
    color=TEXT
):
    surface = font.render(
        str(text),
        True,
        color
    )

    screen.blit(
        surface,
        (
            x,
            y
        )
    )


def tile_rect(
    x,
    y
):
    return pygame.Rect(
        BOARD_X + x * TILE_SIZE + 2,
        BOARD_Y + y * TILE_SIZE + 2,
        TILE_SIZE - 6,
        TILE_SIZE - 6
    )


def tile_center(
    x,
    y
):
    return (
        BOARD_X
        +
        x * TILE_SIZE
        +
        TILE_SIZE // 2,

        BOARD_Y
        +
        y * TILE_SIZE
        +
        TILE_SIZE // 2
    )


def mouse_to_tile(
    position
):
    mouse_x, mouse_y = position

    if not (
        BOARD_X
        <= mouse_x
        <
        BOARD_X + BOARD_WIDTH
    ):
        return None

    if not (
        BOARD_Y
        <= mouse_y
        <
        BOARD_Y + BOARD_HEIGHT
    ):
        return None

    x = (
        mouse_x
        -
        BOARD_X
    ) // TILE_SIZE

    y = (
        mouse_y
        -
        BOARD_Y
    ) // TILE_SIZE

    if (
        0 <= x < BOARD_SIZE
        and
        0 <= y < BOARD_SIZE
    ):
        return (
            x,
            y
        )

    return None


# =============================================================
# ФОН
# =============================================================

def draw_background():

    screen.fill(
        BG
    )

    stars = [

        (25, 50),
        (100, 35),
        (175, 65),
        (250, 25),
        (330, 55),
        (420, 40),
        (510, 70),
        (600, 30),
        (690, 60),
        (780, 35),
        (870, 75),
        (940, 25),

        (50, 210),
        (130, 280),
        (230, 190),
        (350, 260),
        (470, 220),
        (580, 300),
        (720, 190),
        (840, 270),
        (930, 210),

        (20, 520),
        (110, 580),
        (210, 500),
        (320, 570),
        (430, 520),
        (560, 600),
        (700, 540),
        (820, 590),
        (950, 510),
    ]

    for x, y in stars:

        pygame.draw.circle(
            screen,
            (
                75,
                95,
                130
            ),
            (
                x,
                y
            ),
            1
        )


# =============================================================
# КЛЕТКА
# =============================================================

def draw_tile(
    tile,
    x,
    y
):

    rect = tile_rect(
        x,
        y
    )

    # ---------------------------------------------------------
    # Цвет клетки
    # ---------------------------------------------------------

    if not tile.revealed:

        color = (
            14,
            22,
            40
        )

    else:

        colors = {

            "empty": (
                22,
                35,
                56
            ),

            "planet": (
                25,
                70,
                65
            ),

            "station": (
                55,
                58,
                100
            ),

            "asteroid": (
                65,
                55,
                45
            ),

            "anomaly": (
                65,
                40,
                90
            ),

            "pirate": (
                85,
                38,
                45
            ),

            "center": (
                90,
                68,
                25
            ),

            "player_base": (
                30,
                60,
                100
            ),

            "bot_base": (
                70,
                38,
                55
            ),
        }

        color = colors.get(
            tile.kind,
            colors["empty"]
        )

    pygame.draw.rect(
        screen,
        color,
        rect,
        border_radius=8
    )

    pygame.draw.rect(
        screen,
        GRID,
        rect,
        1,
        border_radius=8
    )

    # ---------------------------------------------------------
    # Выбранная клетка
    # ---------------------------------------------------------

    if selected_tile == (
        x,
        y
    ):

        pygame.draw.rect(
            screen,
            CYAN,
            rect,
            3,
            border_radius=8
        )

    # ---------------------------------------------------------
    # Неисследованная клетка
    # ---------------------------------------------------------

    if not tile.revealed:

        draw_text(
            "?",
            rect.centerx - 7,
            rect.centery - 14,
            BIG_FONT,
            MUTED
        )

        return

    cx, cy = tile_center(
        x,
        y
    )

    # ---------------------------------------------------------
    # Пустая клетка
    # ---------------------------------------------------------

    if tile.kind == "empty":

        pygame.draw.circle(
            screen,
            (
                65,
                85,
                115
            ),
            (
                cx,
                cy
            ),
            3
        )

    # ---------------------------------------------------------
    # Планета
    # ---------------------------------------------------------

    elif tile.kind == "planet":

        pygame.draw.circle(
            screen,
            (
                65,
                170,
                155
            ),
            (
                cx,
                cy
            ),
            18
        )

        pygame.draw.circle(
            screen,
            (
                40,
                115,
                105
            ),
            (
                cx - 5,
                cy - 5
            ),
            7
        )

        pygame.draw.arc(
            screen,
            (
                175,
                235,
                225
            ),
            (
                cx - 28,
                cy - 9,
                56,
                18
            ),
            0.2,
            2.9,
            2
        )

    # ---------------------------------------------------------
    # Станция
    # ---------------------------------------------------------

    elif tile.kind == "station":

        pygame.draw.rect(
            screen,
            (
                150,
                165,
                225
            ),
            (
                cx - 17,
                cy - 17,
                34,
                34
            ),
            2,
            border_radius=5
        )

        pygame.draw.line(
            screen,
            WHITE,
            (
                cx - 25,
                cy
            ),
            (
                cx + 25,
                cy
            ),
            3
        )

        pygame.draw.line(
            screen,
            WHITE,
            (
                cx,
                cy - 25
            ),
            (
                cx,
                cy + 25
            ),
            3
        )

        pygame.draw.circle(
            screen,
            CYAN,
            (
                cx,
                cy
            ),
            5
        )

    # ---------------------------------------------------------
    # Астероид
    # ---------------------------------------------------------

    elif tile.kind == "asteroid":

        points = [

            (
                cx - 20,
                cy - 5
            ),

            (
                cx - 10,
                cy - 20
            ),

            (
                cx + 10,
                cy - 17
            ),

            (
                cx + 21,
                cy + 2
            ),

            (
                cx + 8,
                cy + 19
            ),

            (
                cx - 15,
                cy + 15
            ),
        ]

        pygame.draw.polygon(
            screen,
            (
                145,
                115,
                85
            ),
            points
        )

    # ---------------------------------------------------------
    # Аномалия
    # ---------------------------------------------------------

    elif tile.kind == "anomaly":

        pygame.draw.circle(
            screen,
            PURPLE,
            (
                cx,
                cy
            ),
            22,
            3
        )

        pygame.draw.circle(
            screen,
            (
                215,
                145,
                255
            ),
            (
                cx,
                cy
            ),
            8
        )

        pygame.draw.circle(
            screen,
            PURPLE,
            (
                cx,
                cy
            ),
            14,
            1
        )

    # ---------------------------------------------------------
    # Пираты
    # ---------------------------------------------------------

    elif tile.kind == "pirate":

        pygame.draw.circle(
            screen,
            RED,
            (
                cx,
                cy
            ),
            20,
            3
        )

        pygame.draw.line(
            screen,
            RED,
            (
                cx - 14,
                cy - 14
            ),
            (
                cx + 14,
                cy + 14
            ),
            4
        )

        pygame.draw.line(
            screen,
            RED,
            (
                cx + 14,
                cy - 14
            ),
            (
                cx - 14,
                cy + 14
            ),
            4
        )

    # ---------------------------------------------------------
    # Центр
    # ---------------------------------------------------------

    elif tile.kind == "center":

        pygame.draw.circle(
            screen,
            GOLD,
            (
                cx,
                cy
            ),
            22,
            2
        )

        pygame.draw.circle(
            screen,
            (
                255,
                225,
                130
            ),
            (
                cx,
                cy
            ),
            7
        )

        for dx, dy in [

            (0, -28),
            (28, 0),
            (0, 28),
            (-28, 0)

        ]:

            pygame.draw.line(
                screen,
                GOLD,
                (
                    cx,
                    cy
                ),
                (
                    cx + dx,
                    cy + dy
                ),
                2
            )

    # ---------------------------------------------------------
    # База
    # ---------------------------------------------------------

    elif tile.kind in (
        "player_base",
        "bot_base"
    ):

        color = (
            CYAN
            if tile.kind == "player_base"
            else RED
        )

        pygame.draw.rect(
            screen,
            color,
            (
                cx - 20,
                cy - 14,
                40,
                28
            ),
            2,
            border_radius=5
        )

        pygame.draw.line(
            screen,
            color,
            (
                cx,
                cy - 22
            ),
            (
                cx,
                cy + 22
            ),
            3
        )

        pygame.draw.line(
            screen,
            color,
            (
                cx - 13,
                cy
            ),
            (
                cx + 13,
                cy
            ),
            2
        )


# =============================================================
# КОРАБЛЬ ИГРОКА
# =============================================================

def draw_player():

    cx, cy = tile_center(
        game.player.x,
        game.player.y
    )

    points = [

        (
            cx + 22,
            cy
        ),

        (
            cx - 12,
            cy - 13
        ),

        (
            cx - 5,
            cy
        ),

        (
            cx - 12,
            cy + 13
        ),
    ]

    pygame.draw.polygon(
        screen,
        CYAN,
        points
    )

    pygame.draw.circle(
        screen,
        WHITE,
        (
            cx + 3,
            cy
        ),
        4
    )

    # Двигатель
    pygame.draw.line(
        screen,
        GOLD,
        (
            cx - 13,
            cy
        ),
        (
            cx - 22,
            cy
        ),
        3
    )


# =============================================================
# КОРАБЛЬ БОТА
# =============================================================

def draw_bot():

    cx, cy = tile_center(
        game.bot.x,
        game.bot.y
    )

    points = [

        (
            cx - 22,
            cy
        ),

        (
            cx + 12,
            cy - 13
        ),

        (
            cx + 5,
            cy
        ),

        (
            cx + 12,
            cy + 13
        ),
    ]

    pygame.draw.polygon(
        screen,
        RED,
        points
    )

    pygame.draw.circle(
        screen,
        WHITE,
        (
            cx - 3,
            cy
        ),
        4
    )


# =============================================================
# КАРТА
# =============================================================

def draw_board():

    for y in range(
        BOARD_SIZE
    ):

        for x in range(
            BOARD_SIZE
        ):

            tile = game.board.get(
                x,
                y
            )

            draw_tile(
                tile,
                x,
                y
            )

    draw_player()

    draw_bot()


# =============================================================
# ВЕРХНЯЯ ПАНЕЛЬ
# =============================================================

def draw_header():

    draw_text(
        "ПОСЛЕДНИЙ СЕКТОР",
        30,
        20,
        BIG_FONT
    )

    seconds = game.time_left()

    draw_text(
        f"⏱ "
        f"{seconds // 60:02d}:"
        f"{seconds % 60:02d}",
        330,
        27
    )

    draw_text(
        f"HP: {game.player.hp}/3",
        450,
        27
    )

    draw_text(
        f"🛡 {game.player.shield}",
        550,
        27
    )

    draw_text(
        f"Fuel: {game.player.fuel}/10",
        650,
        27
    )

    draw_text(
        f"Score: {game.player.score}",
        790,
        27
    )


# =============================================================
# ПРАВАЯ ПАНЕЛЬ
# =============================================================

def draw_sidebar():

    panel_x = 610

    draw_text(
        "ГРУЗ",
        panel_x,
        90,
        BIG_FONT
    )

    if game.player.cargo:

        for i, item in enumerate(
            game.player.cargo
        ):

            draw_text(
                f"{item.name}: {item.value}",
                panel_x,
                140 + i * 28,
                SMALL_FONT
            )

    else:

        draw_text(
            "Пусто",
            panel_x,
            140,
            SMALL_FONT
        )

    draw_text(
        f"Слоты: "
        f"{game.player.cargo_slots()}/3",
        panel_x,
        255
    )

    draw_text(
        f"Движение: "
        f"{game.player.moves}",
        panel_x,
        290
    )

    draw_text(
        "УПРАВЛЕНИЕ",
        panel_x,
        350,
        BIG_FONT
    )

    controls = [

        "ЛКМ — движение",

        "ПКМ — действия",

        "WASD / ЦФЫВ",

        "SPACE — конец хода",

        "E / У — сканер",

        "R / К — ремонт",

        "F / А — атака",

        "G / П — ограбление",

        "N / Т — новая игра",

    ]

    for i, text in enumerate(
        controls
    ):

        draw_text(
            text,
            panel_x,
            395 + i * 25,
            SMALL_FONT
        )


# =============================================================
# ЖУРНАЛ
# =============================================================

def draw_log():

    log_rect = pygame.Rect(
        30,
        645,
        560,
        105
    )

    pygame.draw.rect(
        screen,
        PANEL,
        log_rect,
        border_radius=8
    )

    pygame.draw.rect(
        screen,
        GRID,
        log_rect,
        1,
        border_radius=8
    )

    draw_text(
        "ЖУРНАЛ",
        40,
        650,
        BIG_FONT
    )

    total = len(
        game.messages
    )

    visible_lines = 4

    if total > visible_lines:

        if game.log_scroll == 0:

            status = "▼ последние"

        else:

            status = (
                f"↑ история: "
                f"{game.log_scroll}"
            )

        draw_text(
            status,
            175,
            660,
            SMALL_FONT,
            MUTED
        )

    end_index = (
        total
        -
        game.log_scroll
    )

    start_index = max(
        0,
        end_index - visible_lines
    )

    messages = game.messages[
        start_index:end_index
    ]

    for i, (
        message,
        kind
    ) in enumerate(
        messages
    ):

        if kind == "danger":

            color = RED

        elif kind == "warning":

            color = GOLD

        elif kind == "good":

            color = GREEN

        else:

            color = (
                190,
                200,
                220
            )

        if len(message) > 65:

            message = (
                message[:62]
                +
                "..."
            )

        draw_text(
            message,
            40,
            688 + i * 18,
            SMALL_FONT,
            color
        )


# =============================================================
# ДЕЙСТВИЯ
# =============================================================

def get_actions(
    x,
    y
):

    tile = game.board.get(
        x,
        y
    )

    actions = []

    distance = (
        abs(game.player.x - x)
        +
        abs(game.player.y - y)
    )

    # ---------------------------------------------------------
    # Движение
    # ---------------------------------------------------------

    if distance == 1:

        actions.append(
            (
                "Двигаться",

                lambda: game.move_player(
                    x - game.player.x,
                    y - game.player.y
                )
            )
        )

    # ---------------------------------------------------------
    # Действия на открытых клетках
    # ---------------------------------------------------------

    if tile.revealed:

        if tile.kind == "planet":

            actions.append(
                (
                    "Исследовать",

                    lambda: game.scan()
                )
            )

        if tile.kind == "station":

            actions.append(
                (
                    "Ремонт",

                    lambda: game.repair()
                )
            )

        if tile.kind == "pirate":

            actions.append(
                (
                    "Атаковать",

                    lambda: game.player_attack()
                )
            )

            actions.append(
                (
                    "Ограбить",

                    lambda: game.player_steal()
                )
            )

    return actions


# =============================================================
# ОТКРЫТЬ МЕНЮ
# =============================================================

def open_action_menu(
    x,
    y
):

    global action_menu
    global selected_tile

    selected_tile = (
        x,
        y
    )

    actions = get_actions(
        x,
        y
    )

    if not actions:

        action_menu = None

        game.log(
            "Для этой клетки нет доступных действий.",
            "warning"
        )

        return

    menu_width = 190

    row_height = 42

    menu_height = (
        len(actions)
        *
        row_height
        +
        12
    )

    px = (
        BOARD_X
        +
        x * TILE_SIZE
        +
        TILE_SIZE
    )

    py = (
        BOARD_Y
        +
        y * TILE_SIZE
    )

    # Справа не помещается.
    if (
        px + menu_width
        >
        SCREEN_WIDTH
    ):

        px = (
            BOARD_X
            +
            x * TILE_SIZE
            -
            menu_width
        )

    # Снизу не помещается.
    if (
        py + menu_height
        >
        SCREEN_HEIGHT
    ):

        py = (
            SCREEN_HEIGHT
            -
            menu_height
            -
            10
        )

    action_menu = {

        "x": px,

        "y": py,

        "width": menu_width,

        "height": menu_height,

        "actions": actions,
    }


# =============================================================
# РИСОВАНИЕ МЕНЮ
# =============================================================

def draw_action_menu():

    if action_menu is None:

        return

    x = action_menu["x"]

    y = action_menu["y"]

    width = action_menu["width"]

    height = action_menu["height"]

    actions = action_menu["actions"]

    # ---------------------------------------------------------
    # Тень
    # ---------------------------------------------------------

    shadow = pygame.Rect(
        x + 5,
        y + 5,
        width,
        height
    )

    pygame.draw.rect(
        screen,
        (
            0,
            0,
            0
        ),
        shadow,
        border_radius=10
    )

    # ---------------------------------------------------------
    # Панель
    # ---------------------------------------------------------

    panel = pygame.Rect(
        x,
        y,
        width,
        height
    )

    pygame.draw.rect(
        screen,
        PANEL_LIGHT,
        panel,
        border_radius=10
    )

    pygame.draw.rect(
        screen,
        (
            65,
            90,
            125
        ),
        panel,
        2,
        border_radius=10
    )

    # ---------------------------------------------------------
    # Кнопки
    # ---------------------------------------------------------

    mouse_pos = pygame.mouse.get_pos()

    for i, (
        title,
        callback
    ) in enumerate(
        actions
    ):

        button = pygame.Rect(
            x + 6,
            y + 6 + i * 42,
            width - 12,
            36
        )

        if button.collidepoint(
            mouse_pos
        ):

            color = (
                45,
                75,
                105
            )

        else:

            color = (
                25,
                38,
                58
            )

        pygame.draw.rect(
            screen,
            color,
            button,
            border_radius=6
        )

        draw_text(
            title,
            button.x + 12,
            button.y + 9,
            SMALL_FONT,
            WHITE
        )


# =============================================================
# ЛКМ
# =============================================================

def handle_left_click(
    position
):

    global action_menu

    # ---------------------------------------------------------
    # Если открыто меню
    # ---------------------------------------------------------

    if action_menu is not None:

        x = action_menu["x"]

        y = action_menu["y"]

        width = action_menu["width"]

        actions = action_menu["actions"]

        for i, (
            title,
            callback
        ) in enumerate(
            actions
        ):

            button = pygame.Rect(
                x + 6,
                y + 6 + i * 42,
                width - 12,
                36
            )

            if button.collidepoint(
                position
            ):

                action_menu = None

                callback()

                return

        # Клик вне меню.
        action_menu = None

        return

    # ---------------------------------------------------------
    # Получаем клетку
    # ---------------------------------------------------------

    target = mouse_to_tile(
        position
    )

    if target is None:

        return

    x, y = target

    # ---------------------------------------------------------
    # ЛКМ = движение
    # ---------------------------------------------------------

    distance = (
        abs(game.player.x - x)
        +
        abs(game.player.y - y)
    )

    if distance == 1:

        game.move_player(
            x - game.player.x,
            y - game.player.y
        )

    else:

        game.log(
            "ЛКМ: выбери соседнюю клетку.",
            "warning"
        )


# =============================================================
# ПКМ
# =============================================================

def handle_right_click(
    position
):

    target = mouse_to_tile(
        position
    )

    if target is None:

        return

    x, y = target

    open_action_menu(
        x,
        y
    )


# =============================================================
# КЛАВИАТУРА
# =============================================================

def handle_key(
    event
):

    global game
    global action_menu

    char = (
        event.unicode.lower()
    )

    # ---------------------------------------------------------
    # Новая игра
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_n
        or
        char == "т"
    ):

        game = Game()

        action_menu = None

        return

    # ---------------------------------------------------------
    # Журнал
    # ---------------------------------------------------------

    if event.key == pygame.K_PAGEUP:

        game.scroll_log(
            3
        )

        return

    if event.key == pygame.K_PAGEDOWN:

        game.scroll_log(
            -3
        )

        return

    if event.key == pygame.K_HOME:

        game.log_to_top()

        return

    if event.key == pygame.K_END:

        game.log_to_bottom()

        return

    # ---------------------------------------------------------
    # ESC
    # ---------------------------------------------------------

    if event.key == pygame.K_ESCAPE:

        action_menu = None

        return

    if game.game_over:

        return

    # ---------------------------------------------------------
    # Вверх
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_UP
        or
        event.key == pygame.K_w
        or
        char == "ц"
    ):

        game.move_player(
            0,
            -1
        )

        return

    # ---------------------------------------------------------
    # Вниз
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_DOWN
        or
        event.key == pygame.K_s
        or
        char == "ы"
    ):

        game.move_player(
            0,
            1
        )

        return

    # ---------------------------------------------------------
    # Влево
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_LEFT
        or
        event.key == pygame.K_a
        or
        char == "ф"
    ):

        game.move_player(
            -1,
            0
        )

        return

    # ---------------------------------------------------------
    # Вправо
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_RIGHT
        or
        event.key == pygame.K_d
        or
        char == "в"
    ):

        game.move_player(
            1,
            0
        )

        return

    # ---------------------------------------------------------
    # Конец хода
    # ---------------------------------------------------------

    if event.key == pygame.K_SPACE:

        game.end_turn()

        return

    # ---------------------------------------------------------
    # Сканер
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_e
        or
        char == "у"
    ):

        game.scan()

        return

    # ---------------------------------------------------------
    # Ремонт
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_r
        or
        char == "к"
    ):

        game.repair()

        return

    # ---------------------------------------------------------
    # Атака
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_f
        or
        char == "а"
    ):

        game.player_attack()

        return

    # ---------------------------------------------------------
    # Ограбление
    # ---------------------------------------------------------

    if (
        event.key == pygame.K_g
        or
        char == "п"
    ):

        game.player_steal()

        return


# =============================================================
# ЭКРАН ОКОНЧАНИЯ ИГРЫ
# =============================================================

def draw_game_over():

    if not game.game_over:

        return

    # ---------------------------------------------------------
    # Затемнение
    # ---------------------------------------------------------

    overlay = pygame.Surface(
        (
            SCREEN_WIDTH,
            SCREEN_HEIGHT
        ),
        pygame.SRCALPHA
    )

    overlay.fill(
        (
            0,
            0,
            0,
            190
        )
    )

    screen.blit(
        overlay,
        (
            0,
            0
        )
    )

    # ---------------------------------------------------------
    # Итоговые очки
    # ---------------------------------------------------------

    player_score, bot_score = (
        game.final_scores()
    )

    if player_score > bot_score:

        result = "ПОБЕДА!"

        result_color = GREEN

    elif player_score < bot_score:

        result = "ПОРАЖЕНИЕ"

        result_color = RED

    else:

        result = "НИЧЬЯ"

        result_color = GOLD

    # ---------------------------------------------------------
    # Центральная панель
    # ---------------------------------------------------------

    panel_width = 420

    panel_height = 240

    panel_x = (
        SCREEN_WIDTH
        -
        panel_width
    ) // 2

    panel_y = (
        SCREEN_HEIGHT
        -
        panel_height
    ) // 2

    panel = pygame.Rect(
        panel_x,
        panel_y,
        panel_width,
        panel_height
    )

    pygame.draw.rect(
        screen,
        PANEL,
        panel,
        border_radius=15
    )

    pygame.draw.rect(
        screen,
        GRID,
        panel,
        2,
        border_radius=15
    )

    # ---------------------------------------------------------
    # Результат
    # ---------------------------------------------------------

    result_surface = BIG_FONT.render(
        result,
        True,
        result_color
    )

    result_rect = result_surface.get_rect(
        center=(
            SCREEN_WIDTH // 2,
            panel_y + 55
        )
    )

    screen.blit(
        result_surface,
        result_rect
    )

    # ---------------------------------------------------------
    # Счёт
    # ---------------------------------------------------------

    score_surface = BIG_FONT.render(
        f"{player_score} : {bot_score}",
        True,
        WHITE
    )

    score_rect = score_surface.get_rect(
        center=(
            SCREEN_WIDTH // 2,
            panel_y + 105
        )
    )

    screen.blit(
        score_surface,
        score_rect
    )

    # ---------------------------------------------------------
    # Игрок
    # ---------------------------------------------------------

    draw_text(
        "Ваш результат",
        panel_x + 55,
        panel_y + 145,
        SMALL_FONT,
        MUTED
    )

    draw_text(
        str(player_score),
        panel_x + 55,
        panel_y + 170,
        FONT,
        CYAN
    )

    # ---------------------------------------------------------
    # Бот
    # ---------------------------------------------------------

    draw_text(
        "Противник",
        panel_x + 270,
        panel_y + 145,
        SMALL_FONT,
        MUTED
    )

    draw_text(
        str(bot_score),
        panel_x + 270,
        panel_y + 170,
        FONT,
        RED
    )

    # ---------------------------------------------------------
    # Новая игра
    # ---------------------------------------------------------

    draw_text(
        "N / Т — новая игра",
        panel_x + 120,
        panel_y + 205,
        SMALL_FONT,
        MUTED
    )


# =============================================================
# ГЛАВНЫЙ ЦИКЛ
# =============================================================

def main():

    global game
    global selected_tile
    global action_menu

    running = True

    while running:

        # =====================================================
        # СОБЫТИЯ
        # =====================================================

        for event in pygame.event.get():

            # -------------------------------------------------
            # Закрытие окна
            # -------------------------------------------------

            if event.type == pygame.QUIT:

                running = False

            # -------------------------------------------------
            # Колесо мыши
            # -------------------------------------------------

            elif (
                event.type
                ==
                pygame.MOUSEWHEEL
            ):

                if event.y > 0:

                    game.scroll_log(
                        1
                    )

                elif event.y < 0:

                    game.scroll_log(
                        -1
                    )

            # -------------------------------------------------
            # Кнопки мыши
            # -------------------------------------------------

            elif (
                event.type
                ==
                pygame.MOUSEBUTTONDOWN
            ):

                # ЛКМ
                if event.button == 1:

                    handle_left_click(
                        event.pos
                    )

                # ПКМ
                elif event.button == 3:

                    handle_right_click(
                        event.pos
                    )

            # -------------------------------------------------
            # Клавиатура
            # -------------------------------------------------

            elif (
                event.type
                ==
                pygame.KEYDOWN
            ):

                handle_key(
                    event
                )

        # =====================================================
        # ЛОГИКА ИГРЫ
        # =====================================================

        game.check_time()

        # =====================================================
        # РЕНДЕР
        # =====================================================

        draw_background()

        draw_header()

        draw_board()

        draw_sidebar()

        draw_log()

        # Меню поверх карты.
        draw_action_menu()

        # Экран окончания игры поверх всего.
        draw_game_over()

        # =====================================================
        # ОБНОВЛЕНИЕ ЭКРАНА
        # =====================================================

        pygame.display.flip()

        clock.tick(
            FPS
        )

    pygame.quit()


# =============================================================
# ЗАПУСК
# =============================================================

if __name__ == "__main__":

    main()